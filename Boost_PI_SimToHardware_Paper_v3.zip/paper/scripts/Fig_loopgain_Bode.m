%% Fig_loopgain_Bode.m - loop gain of the reference and optimized designs (averaged model)
% Phase is shifted so that the integrator starts at -90 deg (bode() may return +270 deg).
cfg   = Boost_Config();
gains = {'PID Tuner',[0 0.8837]; 'Calculated',[0.0040 0.4045]; 'PSO, Case 1',[0 0.40855]; 'PSO, Case 2',[0.001 0.41473]};
scen  = [1 5];                           % 1 = Nominal, 5 = Load 20 %
w     = 2*pi*logspace(-1, 3, 2000);
figure('Position',[100 100 900 620]);
for si = 1:numel(scen)
    s  = cfg.S(scen(si),:);
    Vin = cfg.Vin*s(1); R = cfg.R*s(2); L = cfg.L*s(3); C = cfg.C*s(4);
    D  = 1 - Vin/cfg.Vout;  Dp = 1 - D;
    G  = tf(Vin/Dp^2*[-L/(R*Dp^2) 1], [L*C/Dp^2, L/(R*Dp^2), 1]);
    for g = 1:size(gains,1)
        x  = gains{g,2};  Lo = tf([x(1) x(2)],[1 0])*G;
        [mag,ph] = bode(Lo, w);  mag = squeeze(mag);  ph = squeeze(ph);
        ph = ph - 360*round((ph(1)+90)/360);                 % <-- phase fix
        subplot(2,2,si);   semilogx(w/(2*pi), 20*log10(mag), 'LineWidth',1.6); hold on
        subplot(2,2,si+2); semilogx(w/(2*pi), ph,            'LineWidth',1.6); hold on
    end
    subplot(2,2,si);   yline(0,'k:');    grid on; ylim([-100 50]);  ylabel('|L(j\omega)| (dB)'); title(cfg.scenNames{scen(si)});
    if si == 1, legend(gains(:,1),'Location','southwest'); end
    subplot(2,2,si+2); yline(-180,'k:'); grid on; ylim([-400 0]); yticks(-360:90:0); xlabel('Frequency (Hz)'); ylabel('Phase (deg)');
end
exportgraphics(gcf,'fig_loopgain.png','Resolution',300);
