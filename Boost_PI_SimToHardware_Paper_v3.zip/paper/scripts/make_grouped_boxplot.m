%% make_grouped_boxplot.m  -  final-cost distribution figure regenerated from the saved results
% Assumes the two result files created by Main_Run_All.m (renamed after each 30-run experiment):
%   results_A_Kp0.mat   (Case 1, Kp >= 0)      results_B_Kp001.mat (Case 2, Kp >= 0.001)
% Each file contains the struct R with fields R.PSO.J, R.GWO.J, R.GA.J (30 final costs each).
A = load('results_A_Kp0.mat');  B = load('results_B_Kp001.mat');
names = {'PSO','GWO','GA'};  Rs = {A.R, B.R};
cols  = [0.42 0.68 0.84; 0.91 0.47 0.47];            % Case 1 (blue), Case 2 (red)
figure('Position',[100 100 760 440]); hold on
for g = 1:3
    for c = 1:2
        J = Rs{c}.(names{g}).J(:);
        boxplot(J, 'Positions', g + (c-1.5)*0.36, 'Widths', 0.3, 'Colors', cols(c,:), 'Symbol', 'r+');
    end
end
set(gca,'XTick',1:3,'XTickLabel',names,'XLim',[0.4 3.6]); ylabel('Final cost J'); grid on; box on
set(findobj(gca,'Tag','Box'),'LineWidth',1.4);
annotation('textbox',[0.15 0.80 0.3 0.1],'String',{'blue: Case 1 (K_p \ge 0)','red: Case 2 (K_p \ge 0.001)'},'EdgeColor','none');
exportgraphics(gcf,'fig_boxplot_grouped.png','Resolution',300);
% quick check against the tables of the paper
for c = 1:2, for g = 1:3, J = Rs{c}.(names{g}).J; fprintf('Case %d %s: min %.4f mean %.4f std %.4f max %.4f\n',c,names{g},min(J),mean(J),std(J),max(J)); end, end
