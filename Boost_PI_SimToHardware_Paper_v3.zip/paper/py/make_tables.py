from common import *
TAB = os.path.join(ROOT, "tables"); os.makedirs(TAB, exist_ok=True)
def w(name, s): open(os.path.join(TAB, name), "w", encoding="utf8").write(s); print("table", name)
def f(x, n=2):
    if x is None or (isinstance(x, float) and np.isnan(x)): return "--"
    return f"{x:.{n}f}"
def sci(x):
    if abs(x) < 1e-3 and x != 0: return "$<10^{-3}$"
    return f"{x:.3f}"
def esc(s): return s.replace("%", "\\%").replace("&", "\\&").replace("_", "\\_")
HEAD = "\\centering\n\\footnotesize\n\\setlength{\\tabcolsep}{3.5pt}\\renewcommand{\\arraystretch}{1.12}\n"

# ---------- Study B simulation: optimiser statistics (with success counts from the run data)
s = load_sim(); R = s["Res"]; st = sim_table("Table_Optimiser_Statistics.csv")
best = min(np.min(R[a].J) for a in range(4)); nm = ["PSO", "GA", "GWO", "NSGA-II knee"]
rows = ""
for a in range(4):
    r = st.iloc[a]; J = np.atleast_1d(R[a].J)
    rows += f"{nm[a]} & {r.J_best:.4f} & {r.J_median:.4f} & {r.J_mean:.4f} & {r.J_std:.4f} & {r.J_worst:.4f} & {int((J<=best*1.005).sum())}/15 & {int((J<=best*1.02).sum())}/15 & {r.Time_s_per_run:.0f} \\\\\n"
w("tab_sim_stats.tex", "\\begin{table}[!t]\n\\caption{Study~B, simulation: statistics of the final worst-case cost $J$ over 15 independent runs of each optimizer (equal budget of 680 cost evaluations per run). Success = runs within 0.5\\,\\% (2\\,\\%) of the best cost found by any optimizer. For NSGA-II the cost is that of the knee solution, which is not a minimizer of $J$.}\\label{tab:simstats}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n\\textbf{Optimizer} & \\textbf{Best} & \\textbf{Median} & \\textbf{Mean} & \\textbf{Std} & \\textbf{Worst} & \\textbf{Within 0.5\\,\\%} & \\textbf{Within 2\\,\\%} & \\textbf{Time/run (s)} \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")

# p-values
pm = s["pMat"]; pr = [("PSO","GA",0,1),("PSO","GWO",0,2),("PSO","NSGA-II",0,3),("GA","GWO",1,2),("GA","NSGA-II",1,3),("GWO","NSGA-II",2,3)]
def pf(p): return f"{p:.3f}" if p >= 0.001 else f"${p:.1e}$".replace("e-0", "\\times10^{-").replace("e-", "\\times10^{-") .replace("$", "") if False else ("$" + f"{p:.1e}".replace("e-0", "\\times10^{-") + "}$")
rows = " & ".join(["", ""]) 
body = ""
for a, b, i, j in pr:
    p = pm[i, j]; sig = "yes" if p < 0.05/6 else "no"
    body += f"{a} vs {b} & {pf(p)} & {sig} \\\\\n"
w("tab_sim_pvals.tex", "\\begin{table}[!t]\n\\caption{Study~B, simulation: two-sided Wilcoxon rank-sum $p$-values of the final cost $J$ (15 runs per optimizer). With six pairwise comparisons the Bonferroni-corrected level is $0.05/6\\approx0.0083$.}\\label{tab:simp}\n" + HEAD +
  "\\begin{tabular}{lcc}\n\\toprule\n\\textbf{Comparison} & \\textbf{$p$-value} & \\textbf{Significant} \\\\ \\midrule\n" + body + "\\bottomrule\\end{tabular}\n\\end{table}\n")

# analytic worst case + disturbance merged
an = sim_table("Table_Analytic_WorstCase.csv"); ds = sim_table("Table_Disturbance.csv")
rows = ""
for i, r in an.iterrows():
    rows += f"{esc(r.Design)} & {r.Kp:.4f} & {r.Ki:.2f} & {r.WorstOS_pct:.2f} & {r.WorstTs_ms:.1f} & {r.WorstTr_ms:.1f} & {r.WorstIAE_ms:.2f} & {r.MinPM_deg:.1f} & {r.J_worstcase:.4f} \\\\\n"
w("tab_sim_analytic.tex", "\\begin{table}[!t]\n\\caption{Study~B, simulation: worst case over the 17 corner scenarios, averaged (analytic) model. Reference designs come from \\texttt{pidtune} and the PID Tuner app; the lower four rows are the optimizer designs (best of 15 runs).}\\label{tab:simana}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n\\textbf{Design} & $K_p$ & $K_i$ & \\textbf{OS$_{\\max}$ (\\%)} & \\textbf{$T_{s,\\max}$ (ms)} & \\textbf{$T_{r,\\max}$ (ms)} & \\textbf{IAE$_{\\max}$ (ms)} & \\textbf{PM$_{\\min}$ ($^\\circ$)} & $J$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")

mc = sim_table("Table_MonteCarlo.csv"); rows = ""
for (i, r), (_, d) in zip(mc.iterrows(), ds.iterrows()):
    rows += f"{esc(r.Design)} & {r.SpecMet_pct:.1f} & {r.OS_p95_pct:.2f} & {r.Ts_p95_ms:.1f} & {r.PM_min_deg:.1f} & {d.LinePeak_nom_pct:.1f} & {d.LinePeak_worst_pct:.1f} & {d.LineRecov_worst_ms:.1f} & {d.LoadPeak_worst_pct:.2f} \\\\\n"
w("tab_sim_mc.tex", "\\begin{table}[!t]\n\\caption{Study~B, simulation: Monte Carlo robustness (500 random held-out scenarios; specification: overshoot $\\leq10$\\,\\%, $T_s\\leq20$\\,ms, PM $\\geq45^\\circ$; no design was unstable) and disturbance rejection (peak deviation in percent of $V_\\mathrm{ref}$ for a $-20$\\,\\% input-voltage step and a $+20$\\,\\% load-current step).}\\label{tab:simmc}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n & \\multicolumn{4}{c}{\\textbf{Monte Carlo}} & \\multicolumn{3}{c}{\\textbf{Line step ($-20$\\,\\%)}} & \\textbf{Load step} \\\\ \\cmidrule(lr){2-5}\\cmidrule(lr){6-8}\\cmidrule(lr){9-9}\n\\textbf{Design} & \\textbf{Spec met (\\%)} & \\textbf{OS 95th (\\%)} & \\textbf{$T_s$ 95th (ms)} & \\textbf{PM$_{\\min}$ ($^\\circ$)} & \\textbf{Peak nom. (\\%)} & \\textbf{Peak worst (\\%)} & \\textbf{Recovery (ms)} & \\textbf{Peak worst (\\%)} \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")

sv = sim_table("Table_Simulink.csv"); rows = ""
for i, r in sv.iterrows():
    rows += f"{esc(r.Design)} & {r.Kp:.4f} & {r.Ki:.2f} & {r.WorstOS_pct:.2f} & {r.WorstTs_ms:.1f} & {r.WorstTr_ms:.2f} & {r.WorstIAE_ms:.2f} & {r.WorstSteadyErr_V*1e3:.2f} & {r.J_sim:.4f} \\\\\n"
w("tab_sim_switching.tex", "\\begin{table}[!t]\n\\caption{Study~B, simulation: switching-model (Simulink) validation over 25 scenarios (nominal, 15 worst corners, 9 random held-out). Steady error is the worst deviation of the mean output over the last 10\\,\\% of the run.}\\label{tab:simsw}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n\\textbf{Design} & $K_p$ & $K_i$ & \\textbf{OS$_{\\max}$ (\\%)} & \\textbf{$T_{s,\\max}$ (ms)} & \\textbf{$T_{r,\\max}$ (ms)} & \\textbf{IAE$_{\\max}$ (ms)} & \\textbf{$e_\\mathrm{ss}$ (mV)} & $J_\\mathrm{sim}$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")

# ---------- hardware
hs = hw_table("Table_Optimiser_Statistics.csv"); h = load_hw(); rows = ""
for i, r in hs.iterrows():
    rows += f"{r.Algorithm} & {r.J_best:.3f} & {r.J_median:.3f} & {r.J_mean:.3f} & {r.J_std:.3f} & {r.J_worst:.3f} & {r.Kp_best:.4f} & {r.Ki_best:.1f} \\\\\n"
w("tab_hw_stats.tex", "\\begin{table}[!t]\n\\caption{Hardware: statistics of the re-evaluated cost $J$ of the best design of each run (3 runs per optimizer, 360 measured evaluations per run, two re-evaluations per run best). Gains are in Arduino units.}\\label{tab:hwstats}\n" + HEAD +
  "\\begin{tabular}{lcccccccc}\n\\toprule\n\\textbf{Optimizer} & \\textbf{Best} & \\textbf{Median} & \\textbf{Mean} & \\textbf{Std} & \\textbf{Worst} & $K_P$ (best) & $K_I$ (best) \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}\n\\end{table}\n")
pm = h["pMat"]; body = ""
for a, b, i, j in pr:
    body += f"{a} vs {b} & {pm[i,j]:.3f} \\\\\n"
w("tab_hw_pvals.tex", "\\begin{table}[!t]\n\\caption{Hardware: Wilcoxon rank-sum $p$-values of the re-evaluated cost (3 runs per optimizer). With three runs the test has almost no power, so none of these values is used to claim a difference.}\\label{tab:hwp}\n" + HEAD +
  "\\begin{tabular}{lc}\n\\toprule\n\\textbf{Comparison} & \\textbf{$p$-value} \\\\ \\midrule\n" + body + "\\bottomrule\\end{tabular}\n\\end{table}\n")

hv = hw_table("Table_Hardware_Validation.csv"); rows = ""
for i, r in hv.iterrows():
    rows += f"{esc(r.Design)} & {r.Kp:.4f} & {r.Ki:.1f} & {r.WorstOS_pct:.1f}$\\pm${r.OS_sd:.1f} & {r.WorstTr_ms:.1f} & {r.WorstTs_ms:.0f}$\\pm${r.Ts_sd:.0f} & {r.WorstSSerr_pct:.2f} & {r.Ripple_pct:.2f} & {r.J_mean:.3f}$\\pm${r.J_sd:.3f} \\\\\n"
w("tab_hw_valid.tex", "\\begin{table}[!t]\n\\caption{Hardware validation: worst case over the four steps $8\\to12\\to15\\to12\\to8$\\,V, mean $\\pm$ standard deviation of three repeats. Gains are in Arduino units. The first two rows are the reference designs measured on the bench; the other rows are the best design of each optimizer.}\\label{tab:hwval}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n\\textbf{Design} & $K_P$ & $K_I$ & \\textbf{OS (\\%)} & \\textbf{$T_r$ (ms)} & \\textbf{$T_s$ (ms)} & \\textbf{$e_\\mathrm{ss}$ (\\%)} & \\textbf{Ripple (\\%)} & $J$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")

he = hw_table("Table_Hardware_Ensemble.csv"); rows = ""
for i, r in he.iterrows():
    rows += f"{esc(r.Design)} & {r.OS_pct_ens:.2f} & {r.Tr_ms_ens:.1f} & {r.Ts_ms_ens:.0f} & {r.SSerr_pct_ens:.2f} \\\\\n"
w("tab_hw_ens.tex", "\\begin{table}[!t]\n\\caption{Hardware: ensemble-averaged metrics (the three repeats are averaged before the metrics are computed, which lowers the noise by $\\sqrt3$), worst over the four steps.}\\label{tab:hwens}\n" + HEAD +
  "\\begin{tabular}{lcccc}\n\\toprule\n\\textbf{Design} & \\textbf{OS (\\%)} & \\textbf{$T_r$ (ms)} & \\textbf{$T_s$ (ms)} & \\textbf{$e_\\mathrm{ss}$ (\\%)} \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}\n\\end{table}\n")

rd = hw_table("Table_Recommended_Design.csv"); rows = ""
for i, r in rd.iterrows():
    rows += f"{r.Step.replace('->', '$\\to$')}\\,V & {r.OS_pct:.2f} & {r.Tr_ms:.1f} & {r.Ts_ms:.0f} & {r.SSerr_pct:.2f} & {r.Ripple_pct:.2f} \\\\\n"
w("tab_hw_rec.tex", "\\begin{table}[!t]\n\\caption{Hardware: step-by-step ensemble metrics of the design with the lowest validation cost (GA, $K_P=0.0601$, $K_I=48.24$).}\\label{tab:hwrec}\n" + HEAD +
  "\\begin{tabular}{lccccc}\n\\toprule\n\\textbf{Step} & \\textbf{OS (\\%)} & \\textbf{$T_r$ (ms)} & \\textbf{$T_s$ (ms)} & \\textbf{$e_\\mathrm{ss}$ (\\%)} & \\textbf{Ripple (\\%)} \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}\n\\end{table}\n")

# ---------- transfer
t = hw_table("Table_Sim_vs_Hardware.csv"); rows = ""
lab = {"Sim-GWO": "Simulation best (GWO)", "Sim-NSGA-II": "NSGA-II knee", "Sim pidtune wc300": "\\texttt{pidtune}, $\\omega_c=300$\\,rad/s", "Sim Slider": "PID Tuner app (slider)"}
for i, r in t.iterrows():
    rows += f"{lab[r.Design]} & {r.Kp_sim:.4f} & {r.Ki_sim:.2f} & {r.Kp_hw:.4f} & {r.Ki_hw:.1f} & {r.SimOS_pct:.1f} & {r.SimTs_ms:.1f} & {r.HwOS_pct:.1f} & {r.HwTs_ms:.0f} & {r.HwJ:.2f} \\\\\n"
w("tab_transfer.tex", "\\begin{table}[!t]\n\\caption{Transfer of simulation designs to the hardware: simulation gains, scaled Arduino gains ($K_\\mathrm{hw}=6.23\\,K_\\mathrm{sim}$), worst-case switching-simulation metrics and measured hardware metrics.}\\label{tab:transfer}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lccccccccc}\n\\toprule\n & \\multicolumn{2}{c}{\\textbf{Simulation gains}} & \\multicolumn{2}{c}{\\textbf{Scaled gains}} & \\multicolumn{2}{c}{\\textbf{Simulation}} & \\multicolumn{3}{c}{\\textbf{Hardware}} \\\\ \\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\\cmidrule(lr){8-10}\n\\textbf{Design} & $K_p$ & $K_i$ & $K_P$ & $K_I$ & OS (\\%) & $T_s$ (ms) & OS (\\%) & $T_s$ (ms) & $J$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")

# hardware optimum expressed in simulation units
rows = ""
nmx = ["PSO", "GA", "GWO", "NSGA-II knee"]
for a in range(4):
    r = hs.iloc[a]; kp, ki = r.Kp_best, r.Ki_best
    rows += f"{nmx[a]} & {kp:.4f} & {ki:.1f} & {kp/SCALE:.4f} & {ki/SCALE:.1f} & {45.0/(ki/SCALE):.1f} \\\\\n"
for nme, kp, ki in [("Baseline", 0.1, 20.0), ("Reference", 0.05, 10.0)]:
    rows += f"{nme} & {kp:.4f} & {ki:.1f} & {kp/SCALE:.4f} & {ki/SCALE:.1f} & {45.0/(ki/SCALE):.1f} \\\\\n"
w("tab_gain_domain.tex", "\\begin{table}[!t]\n\\caption{Best hardware gains (Arduino units) converted back to simulation units by dividing by $S=6.23$, and the ratio of the simulation optimum $K_i=45.0$ to the converted integral gain.}\\label{tab:gaindom}\n" + HEAD +
  "\\begin{tabular}{lccccc}\n\\toprule\n\\textbf{Design} & $K_P$ & $K_I$ & $K_P/S$ & $K_I/S$ & $45.0/(K_I/S)$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}\n\\end{table}\n")

# ---------- first-order delay estimate
from scipy.optimize import brentq
def pm_est(Kp, Ki, G0, tau):
    Kp = max(Kp, 1e-9)
    wc = brentq(lambda w: abs((Kp+Ki/(1j*w))*G0)-1, 1e-3, 1e6)
    return wc, np.degrees(np.angle((Kp+Ki/(1j*wc))*G0) - wc*tau) + 180
tr = hw_table("Table_Sim_vs_Hardware.csv"); hvv = hw_table("Table_Hardware_Validation.csv")
rt = sio.loadmat(os.path.join(DATA, "extra", "HW_Retest.mat"), squeeze_me=True, struct_as_record=False)["R"][:, :, 0].mean(1)
G0 = 28.0
kg, kgi = tr.Kp_sim[0], tr.Ki_sim[0]
items = [("Simulation best (GWO), scaled", kg, kgi, rt[0]), ("NSGA-II knee, scaled", tr.Kp_sim[1], tr.Ki_sim[1], rt[1]),
         ("PID Tuner slider, scaled", tr.Kp_sim[3], tr.Ki_sim[3], rt[2]), ("\\texttt{pidtune} 300\\,rad/s, scaled", tr.Kp_sim[2], tr.Ki_sim[2], rt[3]),
         ("Simulation best, $K_i/3$", kg, kgi/3, rt[4]), ("Simulation best, $K_i/6$", kg, kgi/6, rt[5]),
         ("Hardware GA", hvv.Kp[3]/SCALE, hvv.Ki[3]/SCALE, rt[6]), ("Hardware baseline", hvv.Kp[0]/SCALE, hvv.Ki[0]/SCALE, rt[7]),
         ("Hardware PSO", hvv.Kp[2]/SCALE, hvv.Ki[2]/SCALE, hvv.J_mean[2]), ("Hardware GWO", hvv.Kp[4]/SCALE, hvv.Ki[4]/SCALE, hvv.J_mean[4]),
         ("Hardware NSGA-II knee", hvv.Kp[5]/SCALE, hvv.Ki[5]/SCALE, hvv.J_mean[5]), ("Hardware reference", hvv.Kp[1]/SCALE, hvv.Ki[1]/SCALE, hvv.J_mean[1])]
rows = ""
for n, kp, ki, J in items:
    wc, p1 = pm_est(kp, ki, G0, 1e-3); _, p2 = pm_est(kp, ki, G0, 0.5e-3)
    rows += f"{n} & {ki:.1f} & {wc:.0f} & {p2:.0f} & {p1:.0f} & {J:.2f} \\\\\n"
w("tab_pm_est.tex", "\\begin{table}[!t]\n\\caption{First-order estimate of the effect of the digital delay. Flat plant of gain $G_0=28$\\,V, PI controller in simulation units, pure delay $\\tau$: crossover $\\omega_c$ and phase margin for $\\tau=T_s/2$ and $\\tau=T_s$ ($T_s=1$\\,ms). The last column is the measured bench cost (mean of the five-repeat re-test where available, otherwise of the three-repeat validation; the two sessions differ, see Section~\\ref{sec:transfer2}). The estimate neglects the converter dynamics, quantization and sensor noise.}\\label{tab:pmest}\n" + HEAD +
  "\\begin{tabular}{lccccc}\n\\toprule\n\\textbf{Design} & $K_i$ (sim. units) & $\\omega_c$ (rad/s) & PM, $\\tau=T_s/2$ ($^\\circ$) & PM, $\\tau=T_s$ ($^\\circ$) & Bench $J$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}\n\\end{table}\n")
