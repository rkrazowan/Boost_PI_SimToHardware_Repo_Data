from common import *
from fig_hw import sim_scaled
ALG = ["PSO", "GA", "GWO", "NSGA-II"]

def fig_sim_vs_hw():
    t = hw_table("Table_Sim_vs_Hardware.csv"); v = hw_table("Table_Hardware_Validation.csv")
    lab = ["Sim-GWO", "Sim-NSGA-II", "Sim pidtune\nwc=300", "Sim Slider"]
    x = np.arange(4); w = 0.38
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.7), gridspec_kw={"width_ratios": [1, 1, 1.5]})
    for ax, (cs, ch, yl, ttl) in zip(axs[:2], [("SimOS_pct", "HwOS_pct", "Worst overshoot (%)", "(a) Overshoot"), ("SimTs_ms", "HwTs_ms", "Worst settling time (ms)", "(b) Settling time")]):
        ax.bar(x-w/2, t[cs], w, color="#1f77b4", edgecolor="k", lw=0.5, label="Simulation"); ax.bar(x+w/2, t[ch], w, color=ORANGE, edgecolor="k", lw=0.5, label="Hardware")
        ax.set_xticks(x); ax.set_xticklabels(lab, rotation=60, fontsize=6.5); ax.set_ylabel(yl); panel(ax, ttl)
    axs[0].legend(fontsize=6.8, frameon=False, loc="upper right")
    ax = axs[2]
    names = ["Baseline\n(0.1, 20)", "Ref\n(0.05, 10)", "HW-PSO", "HW-GA", "HW-GWO", "HW-NSGA", "Sim-GWO\nscaled", "Sim-NSGA\nscaled", "Sim wc300\nscaled", "Sim Slider\nscaled"]
    J = list(v["J_mean"]) + list(t["HwJ"]); cols = [GREY[1], GREY[0]] + [COL_ALGO[a] for a in ALG] + ["#2ca02c"]*4
    err = list(v["J_sd"]) + [0]*4
    ax.bar(range(10), J, yerr=err, color=cols, edgecolor="k", lw=0.5, capsize=2)
    ax.set_xticks(range(10)); ax.set_xticklabels(names, rotation=70, fontsize=6); ax.set_ylabel("Hardware cost $J$"); panel(ax, "(c) Hardware cost of all designs")
    fig.tight_layout(w_pad=0.8); save(fig, "fig_sim_vs_hw")

def fig_gain_domain():
    s = load_sim(); h = load_hw(); R = h["Res"]; Rs = s["Res"]
    fig, ax = plt.subplots(figsize=(4.8, 3.6))
    for a, nm in enumerate(ALG):
        x = np.atleast_2d(Rs[a].x); ax.plot(x[:, 0], x[:, 1], "o", color=COL_ALGO[nm], ms=3.5, alpha=0.55, mfc="none")
        xh = np.atleast_2d(R[a].x)/SCALE; ax.plot(xh[:, 0], xh[:, 1], "D", color=COL_ALGO[nm], ms=6, mec="k", mew=0.6)
    kr, ir = np.atleast_1d(s["Kp_ref"]), np.atleast_1d(s["Ki_ref"])
    ax.plot(kr, ir, "s", mfc="#ffe44d", mec="k", ms=5)
    ax.plot(np.array([0.1, 0.05])/SCALE, np.array([20, 10])/SCALE, "^", mfc="#ffe44d", mec="k", ms=6)
    from matplotlib.lines import Line2D
    hnd = [Line2D([0], [0], marker="o", ls="", mfc="none", color="gray", label="simulation optima (15 runs per optimiser)"),
           Line2D([0], [0], marker="D", ls="", mfc="gray", mec="k", color="gray", label="hardware optima (3 runs per optimiser), $\\div S$"),
           Line2D([0], [0], marker="s", ls="", mfc="#ffe44d", mec="k", color="k", label="simulation reference designs"),
           Line2D([0], [0], marker="^", ls="", mfc="#ffe44d", mec="k", color="k", label="hardware baseline / reference, $\\div S$")]
    ax.legend(handles=hnd, fontsize=6.3, loc="upper left", frameon=True)
    ax.set_yscale("log"); ax.set_xlim(-0.001, 0.03); ax.set_ylim(1.2, 400); ax.set_xlabel("$K_p$ (simulation units)"); ax.set_ylabel("$K_i$ (simulation units)")
    save(fig, "fig_gain_domain")

if __name__ == "__main__":
    fig_sim_vs_hw(); fig_gain_domain()
