"""Sensitivity of the design ranking to the cost weights/normalisation (existing data, no new experiments)."""
from common import *
from scipy import stats
v = load_hwval(); s = load_sim(); names_h = [str(n) for n in v["names"]]; names_s = [str(n) for n in s["names"]]
MV = v["MV"]; MS = s["MS"]
W = {"base (0.3, 0.3, 0.4)": (0.3, 0.3, 0.4), "error-weighted (0.5, 0.25, 0.25)": (0.5, 0.25, 0.25), "speed-weighted (0.25, 0.5, 0.25)": (0.25, 0.5, 0.25),
     "overshoot-weighted (0.2, 0.2, 0.6)": (0.2, 0.2, 0.6), "equal (1/3, 1/3, 1/3)": (1/3, 1/3, 1/3)}
def Jhw(M, w, mean_w=0.2, pen=True):          # M: (steps, 8) one repeat -> [IAE OS Ts Tr ess ripple duty noise]
    Js = w[0]*M[:, 0]/0.05 + w[1]*M[:, 2]/0.2 + w[2]*M[:, 1]/5
    if pen: Js = Js + np.maximum(0, M[:, 4]-2) + np.maximum(0, M[:, 5]-5)
    return Js.max() + mean_w*Js.mean()
def Jsim(M, w, mean_w=0.2):                    # M: (scen, 5) [IAE OS Ts Tr PM]; simulation cost without margin penalty detail
    Js = w[0]*M[:, 0]/0.01 + w[1]*M[:, 2]/0.03 + w[2]*M[:, 1]/5
    return Js.max() + mean_w*Js.mean() + 10*max(0, 45-np.nanmin(M[:, 4]))/45
res = {}
for k, w in W.items():
    res[k] = np.array([np.mean([Jhw(MV[d][:, :, r], w) for r in range(3)]) for d in range(6)])
base = res["base (0.3, 0.3, 0.4)"]
print("check base vs table:", np.round(base, 3), hw_table("Table_Hardware_Validation.csv").J_mean.round(3).values)
rows_h = []
for k, J in res.items():
    rho = stats.spearmanr(base, J).statistic; rows_h.append((k, [names_h[i] for i in np.argsort(J)][:2], rho, np.round(J, 2)))
    print("HW", k, "best:", names_h[int(np.argmin(J))], "rho", round(rho, 2), np.round(J, 2))
for mw in (0.0, 0.5):
    J = np.array([np.mean([Jhw(MV[d][:, :, r], (0.3, 0.3, 0.4), mean_w=mw) for r in range(3)]) for d in range(6)])
    print("HW mean-weight", mw, "best", names_h[int(np.argmin(J))], "rho", round(stats.spearmanr(base, J).statistic, 2))
Jn = np.array([np.mean([Jhw(MV[d][:, :, r], (0.3, 0.3, 0.4), pen=False) for r in range(3)]) for d in range(6)])
print("HW no penalties best", names_h[int(np.argmin(Jn))], "rho", round(stats.spearmanr(base, Jn).statistic, 2), np.round(Jn, 2))
# simulation switching-model ranking
bs = np.array([Jsim(MS[d], (0.3, 0.3, 0.4)) for d in range(9)])
print("SIM base", np.round(bs, 3), "paper", sim_table("Table_Simulink.csv").J_sim.round(3).values)
out = []
for k, w in W.items():
    J = np.array([Jsim(MS[d], w) for d in range(9)]); rho = stats.spearmanr(bs, J).statistic
    print("SIM", k, "best:", names_s[int(np.argmin(J))], "rho", round(rho, 2)); out.append((k, names_s[int(np.argmin(J))], rho))

# ------------- LaTeX table
rows = ""
def nm_h(i): return names_h[i].replace("NSGA-II knee", "NSGA-II").replace("Baseline (0.1, 20)", "Baseline").replace("Ref (0.05, 10)", "Reference")
def nm_s(i): return names_s[i].replace(" knee", "").replace("Auto (app)", "PID Tuner auto").replace("Slider (app)", "PID Tuner slider")
variants = [(k, W[k], 0.2, True) for k in W] + [("base weights, mean-term weight 0", (0.3,0.3,0.4), 0.0, True), ("base weights, mean-term weight 0.5", (0.3,0.3,0.4), 0.5, True), ("base weights, no steady-state/ripple penalty", (0.3,0.3,0.4), 0.2, False)]
for lab, w, mw, pen in variants:
    Jh = np.array([np.mean([Jhw(MV[d][:, :, r], w, mean_w=mw, pen=pen) for r in range(3)]) for d in range(6)])
    Js_ = np.array([Jsim(MS[d], w, mean_w=mw) for d in range(9)])
    rh = stats.spearmanr(base, Jh).statistic; rs = stats.spearmanr(bs, Js_).statistic
    rows += f"{lab.replace('(', '(').replace('1/3', '1/3')} & {nm_h(int(np.argmin(Jh)))} & {rh:.2f} & {nm_s(int(np.argmin(Js_)))} & {rs:.2f} \\\\\n"
HEAD = "\\centering\n\\footnotesize\n\\setlength{\\tabcolsep}{3.5pt}\\renewcommand{\\arraystretch}{1.12}\n"
open(os.path.join(ROOT, "tables", "tab_costsens.tex"), "w").write("\\begin{table}[!t]\n\\caption{Sensitivity of the design ranking to the cost weights $(w_\\mathrm{IAE},w_{T_s},w_\\mathrm{OS})$ and to the other terms of the cost, recomputed from the stored metrics without new experiments. Hardware: six validated designs; simulation: nine designs of the switching-model validation. $\\rho$ is the Spearman rank correlation with the ranking of the base cost.}\\label{tab:costsens}\n" + HEAD +
  "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccc}\n\\toprule\n & \\multicolumn{2}{c}{\\textbf{Hardware}} & \\multicolumn{2}{c}{\\textbf{Switching simulation}} \\\\ \\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\n\\textbf{Cost variant} & \\textbf{Best design} & $\\rho$ & \\textbf{Best design} & $\\rho$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")
print(rows)
