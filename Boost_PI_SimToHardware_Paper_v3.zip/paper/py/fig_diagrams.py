from common import *

def box(ax, x, y, w, h, text, fc="#ffffff", ec="#444444", fs=7.6, bold=False, lw=1.0, ls="-"):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.025", fc=fc, ec=ec, lw=lw, ls=ls)
    ax.add_patch(p)
    ax.text(x+w/2, y+h/2, text, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal", linespacing=1.25)

def arrow(ax, x0, y0, x1, y1, text=None, style="-|>", color="#333333", ls="-", fs=7, off=(0, 0.018), lw=1.1, rad=0.0):
    a = FancyArrowPatch((x0, y0), (x1, y1), arrowstyle=style, mutation_scale=9, color=color, lw=lw, ls=ls,
                        connectionstyle=f"arc3,rad={rad}")
    ax.add_patch(a)
    if text:
        ax.text((x0+x1)/2+off[0], (y0+y1)/2+off[1], text, ha="center", va="bottom", fontsize=fs, color=color)

def lane(ax, x, y, w, h, title, fc):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.005,rounding_size=0.02", fc=fc, ec="none", alpha=0.55))
    ax.text(x+0.012, y+h-0.018, title, ha="left", va="top", fontsize=8.2, fontweight="bold", color="#222222")

# ---------------------------------------------------------------------------------- overall framework
def fig_framework():
    fig, ax = plt.subplots(figsize=(7.4, 6.6)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off"); ax.grid(False)
    blue, green, orange, grey = "#dbe9ff", "#dcf5e0", "#ffe9d2", "#eceff3"

    lane(ax, 0.01, 0.805, 0.98, 0.185, "Study A: design-level simulation (500 W boost converter, 12 V to 24 V, 10 kHz)", "#eef3fb")
    box(ax, 0.03, 0.825, 0.27, 0.105, "Averaged model + switching\nSimulink model; 7 scenarios;\ncost: ITAE, overshoot, $T_s$,\neffort, margins", blue, fs=7.2)
    box(ax, 0.36, 0.825, 0.27, 0.105, "PSO, GWO, GA, NSGA-II\n30 runs each, two search spaces\n($K_p\\geq0$, $K_p\\geq0.001$)", blue, fs=7.2)
    box(ax, 0.69, 0.825, 0.28, 0.105, "Design insight: integral-dominant\noptimum (RHP zero + LC resonance);\nrobustness vs manual/automatic tuning", grey, fs=7.0)
    arrow(ax, 0.30, 0.8775, 0.36, 0.8775); arrow(ax, 0.63, 0.8775, 0.69, 0.8775)

    lane(ax, 0.01, 0.565, 0.98, 0.225, "Study B, simulation: laboratory-scale converter (10 V input, 18.2 V reference, 62.5 kHz)", "#eaf7ee")
    box(ax, 0.03, 0.585, 0.205, 0.13, "Prototype model\n(Simulink switching +\naveraged model)\n17 corner scenarios", blue, fs=7.0)
    box(ax, 0.265, 0.585, 0.205, 0.13, "Optimisation (averaged)\nPSO, GA, GWO, NSGA-II\n15 runs, equal budget;\nworst-case cost $J$", blue, fs=7.0)
    box(ax, 0.50, 0.585, 0.205, 0.13, "Held-out checks\n500 Monte Carlo samples,\nline and load\ndisturbances", green, fs=7.0)
    box(ax, 0.735, 0.585, 0.235, 0.13, "Switching-model validation\n25 scenarios; ranking;\nbest simulation gains\n($K_p$, $K_i$)", orange, fs=7.0)
    for x0, x1 in [(0.235, 0.265), (0.47, 0.50), (0.705, 0.735)]:
        arrow(ax, x0, 0.65, x1, 0.65)

    box(ax, 0.20, 0.465, 0.60, 0.06, "Gain scaling to the Arduino:  $K_\\mathrm{hw}=S\\,K_\\mathrm{sim}$,  $S=255\\cdot25/1023=6.23$", "#fff6cc", ec="#b8960b", fs=8, bold=True)
    arrow(ax, 0.8525, 0.585, 0.72, 0.525, rad=-0.1)

    lane(ax, 0.01, 0.03, 0.98, 0.41, "Study B, hardware: Arduino Uno + MATLAB serial link (7.2 V supply, 5 V to 18 V reference range)", "#fdf1e4")
    box(ax, 0.03, 0.23, 0.29, 0.11, "(i) Scaled-gain test:\nbest simulation designs\nloaded over the serial link", orange, fs=7.0)
    box(ax, 0.355, 0.23, 0.29, 0.11, "(ii) Hardware-in-the-loop optimisation:\nPSO, GA, GWO, NSGA-II; 3 runs;\n360 measured evaluations per run", orange, fs=6.9)
    box(ax, 0.68, 0.23, 0.29, 0.11, "(iii) Validation, steps\n8 \u2192 12 \u2192 15 \u2192 12 \u2192 8 V,\n3 repeats, noise-aware metrics", orange, fs=6.9)
    arrow(ax, 0.40, 0.465, 0.20, 0.34, rad=0.05)
    arrow(ax, 0.50, 0.465, 0.50, 0.34)
    arrow(ax, 0.645, 0.285, 0.68, 0.285)
    box(ax, 0.03, 0.065, 0.94, 0.095, "Comparison: simulation versus hardware (overshoot, settling time, cost $J$); ranking of hardware-tuned and\nsimulation-scaled designs; sim-to-hardware gap analysis; low-cost implementation guidelines", grey, fs=7.2)
    for x in (0.175, 0.50, 0.825):
        arrow(ax, x, 0.23, x, 0.16)
    save(fig, "fig_framework")

# ---------------------------------------------------------------------------------- hardware block diagram
def fig_hw_diagram():
    fig, ax = plt.subplots(figsize=(7.4, 3.9)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off"); ax.grid(False)
    # power stage
    ax.add_patch(FancyBboxPatch((0.005, 0.40), 0.66, 0.58, boxstyle="round,pad=0.005,rounding_size=0.02", fc="#fdf1e4", ec="none", alpha=0.7))
    ax.text(0.015, 0.955, "Boost power stage", fontsize=8.2, fontweight="bold", va="top")
    box(ax, 0.02, 0.62, 0.11, 0.18, "DC supply\n7.2 V", "#ffffff", fs=7.6)
    box(ax, 0.185, 0.62, 0.09, 0.18, "Inductor\n$L$", "#ffffff", fs=7.6)
    box(ax, 0.2275, 0.43, 0.15, 0.15, "MOSFET +\ndriver module", "#ffe9d2", fs=7.4)
    box(ax, 0.33, 0.62, 0.095, 0.18, "Diode\nSR506", "#ffffff", fs=7.6)
    box(ax, 0.47, 0.62, 0.075, 0.18, "Capacitor\n$C$", "#ffffff", fs=7.2)
    box(ax, 0.575, 0.62, 0.08, 0.18, "Load\n50 $\\Omega$", "#ffffff", fs=7.6)
    for x0, x1 in [(0.13, 0.185), (0.275, 0.33), (0.425, 0.47), (0.545, 0.575)]:
        arrow(ax, x0, 0.71, x1, 0.71, style="-")
    arrow(ax, 0.3025, 0.58, 0.3025, 0.71, style="-", lw=0.9)           # switch node (inductor-diode junction)
    ax.text(0.607, 0.585, "$V_\\mathrm{out}$", fontsize=8.5, ha="left")
    # divider
    box(ax, 0.50, 0.43, 0.16, 0.12, "Divider 40 k\u03a9 / 10 k\u03a9\n($\\times$ 1/5)", "#ffffff", fs=7.2)
    arrow(ax, 0.595, 0.62, 0.595, 0.55, style="-", lw=0.9)
    # Arduino
    ax.add_patch(FancyBboxPatch((0.07, 0.03), 0.60, 0.31, boxstyle="round,pad=0.005,rounding_size=0.02", fc="#dbe9ff", ec="none", alpha=0.7))
    ax.text(0.08, 0.325, "Arduino Uno (ATmega328P)", fontsize=8.2, fontweight="bold", va="top")
    box(ax, 0.09, 0.06, 0.17, 0.15, "Timer1: 8-bit fast PWM\nD9, 62.5 kHz\n(duty 0\u2013200 of 255)", "#ffffff", fs=6.9)
    box(ax, 0.285, 0.06, 0.19, 0.15, "PI loop, $T_s$ = 1 ms\n(incremental form)\n$K_P$, $K_I$, $V_\\mathrm{ref}$", "#ffffff", fs=7.1)
    box(ax, 0.50, 0.06, 0.15, 0.15, "10-bit ADC (A5)\nfeedback; A4:\nlocal pot", "#ffffff", fs=7.0)
    arrow(ax, 0.285, 0.135, 0.26, 0.135, style="-|>")
    arrow(ax, 0.50, 0.135, 0.475, 0.135, style="-|>")
    arrow(ax, 0.175, 0.21, 0.27, 0.43, style="-|>", text="PWM", off=(-0.035, 0.0), fs=7)
    arrow(ax, 0.58, 0.43, 0.58, 0.21, style="-|>")
    # MATLAB
    ax.add_patch(FancyBboxPatch((0.70, 0.03), 0.295, 0.95, boxstyle="round,pad=0.005,rounding_size=0.02", fc="#eceff3", ec="none", alpha=0.8))
    ax.text(0.71, 0.955, "Laptop: MATLAB", fontsize=8.2, fontweight="bold", va="top")
    box(ax, 0.72, 0.68, 0.255, 0.20, "Optimiser\nPSO, GA, GWO, NSGA-II\n(proposes $K_p$, $K_i$)", "#ffffff", fs=7.2)
    box(ax, 0.72, 0.40, 0.255, 0.20, "Test sequence + metrics\nvoltage steps, noise-aware\n$\\mathrm{IAE}$, OS, $T_s$, cost $J$", "#ffffff", fs=7.2)
    box(ax, 0.72, 0.10, 0.255, 0.20, "serialport, 115 200 baud\nKP=, KI=, VREF=, RESET\nDATA, t, $V_\\mathrm{ref}$, $V_\\mathrm{out}$, duty (10 ms)", "#fff6cc", ec="#b8960b", fs=6.6)
    arrow(ax, 0.85, 0.68, 0.85, 0.60, style="<|-|>"); arrow(ax, 0.85, 0.40, 0.85, 0.30, style="<|-|>")
    arrow(ax, 0.72, 0.20, 0.67, 0.14, style="<|-|>", text="USB", off=(0.0, 0.02), fs=7)
    save(fig, "fig_hw_diagram")

# ---------------------------------------------------------------------------------- scaling signal chain
def fig_scaling():
    fig, ax = plt.subplots(figsize=(7.4, 2.35)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off"); ax.grid(False)
    y, h = 0.46, 0.34
    box(ax, 0.01, y, 0.14, h, "Error\n$e_V=V_\\mathrm{ref}-V_\\mathrm{out}$\n[V]", "#ffffff", fs=7.4)
    box(ax, 0.20, y, 0.16, h, "ADC + divider\n$e=e_V\\cdot\\dfrac{1023}{25}$\n[counts]", "#dbe9ff", fs=7.4)
    box(ax, 0.41, y, 0.19, h, "Arduino PI\n$u_k=u_{k-1}+K_P\\,\\Delta e_k+K_I T_s e_k$\n[PWM counts]", "#ffe9d2", fs=7.0)
    box(ax, 0.65, y, 0.14, h, "Clamp\n$0\\leq u\\leq200$\nPWM 8 bit", "#ffffff", fs=7.2)
    box(ax, 0.84, y, 0.15, h, "Duty ratio\n$d=u/255$", "#ffffff", fs=7.4)
    for x0, x1 in [(0.15, 0.20), (0.36, 0.41), (0.60, 0.65), (0.79, 0.84)]:
        arrow(ax, x0, y+h/2, x1, y+h/2)
    ax.text(0.5, 0.20, "Simulation PI: $d=K_\\mathrm{p}\\,e_V+K_\\mathrm{i}\\!\\int e_V\\,dt$   $\\Rightarrow$   "
                       "$K_P=K_\\mathrm{p}\\cdot255\\cdot\\dfrac{25}{1023},\\quad K_I=K_\\mathrm{i}\\cdot255\\cdot\\dfrac{25}{1023}$   "
                       "(same factor $S=6.23$ for both gains)",
            ha="center", va="center", fontsize=8.2)
    save(fig, "fig_scaling")

if __name__ == "__main__":
    fig_framework(); fig_hw_diagram(); fig_scaling()
