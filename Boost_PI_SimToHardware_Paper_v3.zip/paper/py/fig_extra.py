"""Figures/tables for the additional checks: sampled-PI simulation (Part A/B) and bench re-test."""
from common import *
from scipy import stats
import shutil
EX = os.path.join(DATA, "extra")
SHORT = ["Sim-GWO\nscaled", "Sim NSGA-II\nscaled", "Sim slider\nscaled", "Sim pidtune\n300 scaled", "Sim-GWO\n$K_i/3$", "Sim-GWO\n$K_i/6$", "HW GA\n(control)", "Baseline\n(control)"]
LAB = ["Sim-GWO scaled", "Sim NSGA-II scaled", "Sim slider scaled", "Sim pidtune300 scaled", "Sim-GWO, Ki/3", "Sim-GWO, Ki/6", "HW GA (control)", "Baseline (control)"]
COLS = [(0.47,0.67,0.19), (0.30,0.55,0.15), (0.65,0.80,0.45), (0.20,0.45,0.35), (0.95,0.60,0.20), (0.98,0.78,0.45), COL_ALGO["GA"], GREY[1]]

def load():
    m = sio.loadmat(os.path.join(EX, "HW_Retest.mat"), squeeze_me=True, struct_as_record=False)
    A = pd.read_csv(os.path.join(EX, "Sim_Check_Results.csv")); B = pd.read_csv(os.path.join(EX, "Sim_Check_Results_1.csv"))
    return m, A, B

def fig_retest():
    m, A, B = load(); R = m["R"]; J = R[:, :, 0]; OS = R[:, :, 1]
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.0)); x = np.arange(8)
    for ax, V, yl, ttl in [(axs[0], J, "Cost $J$", "(a) Cost over 5 repeats"), (axs[1], OS, "Worst overshoot (%)", "(b) Worst overshoot over 5 repeats")]:
        ax.bar(x, V.mean(1), yerr=V.std(1, ddof=1), color=COLS, edgecolor="k", lw=0.5, capsize=2, alpha=0.85)
        for i in range(8): ax.plot(np.full(V.shape[1], i)+np.linspace(-0.18, 0.18, V.shape[1]), V[i], "k.", ms=3)
        ax.set_xticks(x); ax.set_xticklabels(SHORT, rotation=70, fontsize=6.3); ax.set_ylabel(yl); panel(ax, ttl)
    fig.tight_layout(w_pad=1.2); save(fig, "fig_retest")

def fig_delay():
    m, A, B = load(); a = A.iloc[:6]
    lab = ["Sim-GWO", "Sim NSGA-II", "Sim slider", "Sim pidtune300", "HW GA", "HW baseline"]
    fig, ax = plt.subplots(figsize=(4.8, 3.0)); x = np.arange(6); w = 0.38
    ax.bar(x-w/2, a.A_OS_cont, w, color="#1f77b4", edgecolor="k", lw=0.5, label="continuous PI")
    ax.bar(x+w/2, a.A_OS_disc, w, color=ORANGE, edgecolor="k", lw=0.5, label="sampled PI, $T_s=1$ ms")
    ax.set_yscale("log"); ax.set_ylim(0.01, 300); ax.set_xticks(x); ax.set_xticklabels(lab, rotation=40, ha="right", fontsize=7)
    ax.set_ylabel("Start-up overshoot (%)"); ax.legend(frameon=False, fontsize=7, loc="upper right")
    for i, (c, d) in enumerate(zip(a.A_OS_cont, a.A_OS_disc)): ax.text(i+w/2, d*1.2, f"{d:.0f}" if d >= 10 else f"{d:.1f}", ha="center", fontsize=6)
    save(fig, "fig_delay")

def fig_sim_vs_bench():
    m, A, B = load(); R = m["R"]; bOS = R[:, :, 1].mean(1); bJ = R[:, :, 0].mean(1); sOS = B.B_OS.values; sJ = B.B_J.values
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.2))
    for ax, xs, ys, xl, yl, ttl, lim in [(axs[0], sOS, bOS, "Simulation (sampled PI, 7.2 V) worst overshoot (%)", "Bench worst overshoot (%)", "(a) Overshoot", (0.8, 150)),
                                         (axs[1], sJ, bJ, "Simulation (sampled PI, 7.2 V) cost $J$", "Bench cost $J$", "(b) Cost", (0.15, 15))]:
        for i in range(8):
            ax.plot(xs[i], ys[i], "o", color=COLS[i], mec="k", ms=11)
            ax.annotate(str(i+1), (xs[i], ys[i]), ha="center", va="center", fontsize=6.5, fontweight="bold", color="white" if i in (3,6,7) else "black")
        ax.plot(lim, lim, "k:", lw=0.8); ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(*lim); ax.set_ylim(0.8 if ttl == "(a) Overshoot" else 0.5, 40 if ttl == "(a) Overshoot" else 8)
        ax.set_xlabel(xl, fontsize=8); ax.set_ylabel(yl); panel(ax, ttl)
        from matplotlib.ticker import ScalarFormatter, FixedLocator
        ticks = [1, 2, 5, 10, 20, 50, 100] if ttl == "(a) Overshoot" else [0.3, 0.5, 1, 2, 3, 5, 10]
        for axis in (ax.xaxis, ax.yaxis):
            axis.set_major_locator(FixedLocator(ticks)); axis.set_major_formatter(ScalarFormatter()); axis.set_minor_formatter(plt.NullFormatter())
    r1 = stats.spearmanr(sOS[:7], bOS[:7]).statistic; r2 = stats.spearmanr(sOS, bOS).statistic; r3 = stats.spearmanr(sJ, bJ).statistic
    axs[0].text(0.03, 0.95, f"Spearman $\\rho$ = {r2:.2f} (all 8), {r1:.2f} (without baseline)", transform=axs[0].transAxes, fontsize=6.5, va="top")
    axs[1].text(0.03, 0.95, f"Spearman $\\rho$ = {r3:.2f}", transform=axs[1].transAxes, fontsize=6.5, va="top")
    fig.tight_layout(w_pad=1.2); save(fig, "fig_sim_vs_bench")
    print("rho OS all %.2f, w/o baseline %.2f, J %.2f" % (r2, r1, r3))

def tables():
    m, A, B = load(); R = m["R"]; J = R[:, :, 0]; OS = R[:, :, 1]; Tr = R[:, :, 2].copy(); Tr[Tr < 0.5] = np.nan
    rows = ""; T = m["T"]; kp = [0.100578954545455, 0.122355725843108, 0.0151429618768328, 0.0, 0.100578954545455, 0.100578954545455, 0.0601286462, 0.1]
    ki = [280.201959090909, 288.898575183284, 95.4318181818182, 56.8110337243402, 93.400653030303, 46.7003265151515, 48.2391711951, 20.0]
    nm = ["Simulation best (GWO), scaled", "NSGA-II knee, scaled", "PID Tuner slider, scaled", "\\texttt{pidtune} 300\\,rad/s, scaled", "Simulation best, $K_i/3$", "Simulation best, $K_i/6$", "Hardware GA design (control)", "Baseline gains (control)"]
    for i in range(8):
        rows += f"{nm[i]} & {kp[i]:.4f} & {ki[i]:.1f} & {J[i].mean():.2f}$\\pm${J[i].std(ddof=1):.2f} & {OS[i].mean():.1f}$\\pm${OS[i].std(ddof=1):.1f} & {np.nanmean(Tr[i]):.1f} & {R[i,:,4].mean():.2f} & {R[i,:,5].mean():.2f} & {R[i,:,3].mean():.0f} \\\\\n"
    HEAD = "\\centering\n\\footnotesize\n\\setlength{\\tabcolsep}{3.5pt}\\renewcommand{\\arraystretch}{1.12}\n"
    open(os.path.join(ROOT, "tables", "tab_retest.tex"), "w").write("\\begin{table}[!t]\n\\caption{Bench re-test of the scaled simulation designs, derated versions of the best simulation design, and two control designs: worst case over the four steps $8\\to12\\to15\\to12\\to8$\\,V, mean (and standard deviation for $J$ and OS) of five repeats measured in random order in one session. Gains in Arduino units. One rise-time value of zero (an artefact of the 10--90\\,\\% interpolation) was excluded from the mean $T_r$ of the NSGA-II design.}\\label{tab:retest}\n" + HEAD +
        "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n\\textbf{Design} & $K_P$ & $K_I$ & $J$ & \\textbf{OS (\\%)} & \\textbf{$T_r$ (ms)} & \\textbf{$e_\\mathrm{ss}$ (\\%)} & \\textbf{Ripple (\\%)} & \\textbf{$T_s$ (ms)} \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")
    # sampled-PI simulation table
    a = A.iloc[:6].reset_index(drop=True); rows = ""
    nmS = ["Simulation best (GWO), scaled", "NSGA-II knee, scaled", "PID Tuner slider, scaled", "\\texttt{pidtune} 300\\,rad/s, scaled", "Simulation best, $K_i/3$", "Simulation best, $K_i/6$", "Hardware GA design", "Baseline gains"]
    Aos = {0: (a.A_OS_cont[0], a.A_OS_disc[0]), 1: (a.A_OS_cont[1], a.A_OS_disc[1]), 2: (a.A_OS_cont[2], a.A_OS_disc[2]), 3: (a.A_OS_cont[3], a.A_OS_disc[3]), 6: (a.A_OS_cont[4], a.A_OS_disc[4]), 7: (a.A_OS_cont[5], a.A_OS_disc[5])}
    for i in range(8):
        ac, ad = Aos.get(i, (None, None))
        sa = f"{ac:.1f} & {ad:.1f}" if ac is not None else "-- & --"
        rows += f"{nmS[i]} & {sa} & {B.B_OS[i]:.1f} & {B.B_Ts_ms[i]:.0f} & {B.B_J[i]:.2f} & {OS[i].mean():.1f} & {J[i].mean():.2f} \\\\\n"
    open(os.path.join(ROOT, "tables", "tab_simcheck.tex"), "w").write("\\begin{table}[!t]\n\\caption{Simulation with a sampled PI controller (switching model, $T_s=1$\\,ms). Part A: start-up to 18.18\\,V from $V_\\mathrm{in}=10$\\,V, overshoot with a continuous and with a sampled controller. Part B: $V_\\mathrm{in}=7.2$\\,V, reference steps $8\\to12\\to15\\to12\\to8$\\,V (0.25\\,s each), worst case over the four steps, with the cost of \\eqref{eq:Jhw} without noise penalties. The last two columns repeat the bench result of Table~\\ref{tab:retest}.}\\label{tab:simcheck}\n" + HEAD +
        "\\resizebox{\\textwidth}{!}{%\n\\begin{tabular}{lcccccccc}\n\\toprule\n & \\multicolumn{2}{c}{\\textbf{Part A: OS (\\%)}} & \\multicolumn{3}{c}{\\textbf{Part B: simulation}} & \\multicolumn{2}{c}{\\textbf{Bench}} \\\\ \\cmidrule(lr){2-3}\\cmidrule(lr){4-6}\\cmidrule(lr){7-8}\n\\textbf{Design} & \\textbf{cont.} & \\textbf{sampled} & \\textbf{OS (\\%)} & \\textbf{$T_s$ (ms)} & $J$ & \\textbf{OS (\\%)} & $J$ \\\\ \\midrule\n" + rows + "\\bottomrule\\end{tabular}}\n\\end{table}\n")
    # welch tests for the text
    def w(i, j): return stats.ttest_ind(J[i], J[j], equal_var=False).pvalue
    print("p GA vs GWOsc %.3f; slider vs GWOsc %.3f; GA vs slider %.3f; Ki/3 vs GWOsc %.2f; Ki/6 vs GWOsc %.2f; GWOsc vs base %.2f" % (w(6,0), w(2,0), w(6,2), w(4,0), w(5,0), w(0,7)))

if __name__ == "__main__":
    fig_retest(); fig_delay(); fig_sim_vs_bench(); tables()
    shutil.copy(os.path.join(EX, "Sim_Check_PartB_1.png"), os.path.join(FIG, "fig_simB_traces.png"))
