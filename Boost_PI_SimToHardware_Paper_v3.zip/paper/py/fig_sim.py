from common import *
from matplotlib.lines import Line2D

def algo_names(): return ["PSO", "GA", "GWO", "NSGA-II"]

def fig_sim_conv_stats():
    m = load_sim(); Res = m["Res"]; cfg = m["cfg"]; lim = m["lim"]
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.55), gridspec_kw={"width_ratios": [1.15, 0.9, 1.05]})
    ax = axs[0]
    for a, nm in enumerate(algo_names()):
        h = np.atleast_2d(Res[a].hist); mu = h.mean(0); sd = h.std(0); x = np.arange(h.shape[1])
        ax.fill_between(x, mu-sd, mu+sd, color=COL_ALGO[nm], alpha=0.15, lw=0)
        ax.plot(x, mu, color=COL_ALGO[nm], label=nm)
    ax.set_yscale("log"); ax.set_xlabel("Iteration"); ax.set_ylabel("Worst-case cost $J$"); ax.legend(loc="upper right", frameon=False)
    panel(ax, "(a) Convergence (mean $\\pm$ 1 s.d., 15 runs)")
    ax = axs[1]
    data = [np.atleast_1d(Res[a].J) for a in range(4)]
    bp = ax.boxplot(data, widths=0.55, patch_artist=True, showfliers=False, medianprops=dict(color="k", lw=1.2))
    for p, nm in zip(bp["boxes"], algo_names()):
        p.set_facecolor(COL_ALGO[nm]); p.set_alpha(0.55)
    rng = np.random.default_rng(1)
    for i, d in enumerate(data):
        ax.plot(i+1+rng.uniform(-0.12, 0.12, len(d)), d, "k.", ms=3, alpha=0.6)
    ax.set_xticks(range(1, 5)); ax.set_xticklabels(algo_names(), fontsize=7.5); ax.set_yscale("log"); ax.set_ylabel("Final cost $J$")
    panel(ax, "(b) Final cost over runs")
    ax = axs[2]
    for a, nm in enumerate(algo_names()):
        x = np.atleast_2d(Res[a].x); ax.plot(x[:, 0], x[:, 1], "o", ms=3.6, color=COL_ALGO[nm], alpha=0.8, label=nm)
    refn = [str(s) for s in m["refNames"]]; kr = np.atleast_1d(m["Kp_ref"]); ir = np.atleast_1d(m["Ki_ref"])
    ax.plot(kr, ir, "s", mfc="#ffe44d", mec="k", ms=5.5)
    for k, i_, n in zip(kr, ir, refn):
        ax.annotate(n, (k, i_), xytext=(4, 2), textcoords="offset points", fontsize=6.3)
    ax.set_yscale("log"); ax.set_xlim(-0.001, 0.03); ax.set_ylim(1.5, 150)
    ax.set_xlabel("$K_p$"); ax.set_ylabel("$K_i$"); panel(ax, "(c) Optimised gains (simulation units)")
    fig.tight_layout(w_pad=1.0); save(fig, "fig_sim_conv_stats")

def fig_sim_validation():
    m = load_sim(); tU = m["tU"]*1e3; names = [str(n) for n in m["names"]]
    simV, simD = m["simV"], m["simD"]; Vref = float(m["cfg"].Vref)
    cols = [GREY[0], GREY[1], GREY[2], ORANGE, GREEN] + [COL_ALGO[n] for n in algo_names()]
    ls = ["--"]*5 + ["-"]*4
    fig, axs = plt.subplots(2, 2, figsize=(7.4, 5.0), sharex=True)
    q = [0, 1]; titles = ["nominal", "worst corner ($V_\\mathrm{in}$ 80 %, $L$ 120 %, $C$ 120 %, $R$ 150 %)"]
    for j, qq in enumerate(q):
        for d in range(9):
            axs[0, j].plot(tU, simV[d][:, qq], color=cols[d], ls=ls[d], lw=1.3 if d >= 5 else 1.1, label=names[d])
            axs[1, j].plot(tU, simD[d][:, qq], color=cols[d], ls=ls[d], lw=1.3 if d >= 5 else 1.1)
        axs[0, j].axhline(Vref, color="k", ls=":", lw=1); axs[0, j].set_ylabel("$V_\\mathrm{out}$ (V)")
        axs[1, j].set_ylabel("Duty ratio"); axs[1, j].set_xlabel("Time (ms)")
        panel(axs[0, j], "(%s) $V_\\mathrm{out}$: %s" % ("ab"[j], titles[j])); panel(axs[1, j], "(%s) Duty: %s" % ("cd"[j], titles[j].split(" (")[0]))
        axs[0, j].set_xlim(0, 120)
    axs[0, 0].legend(loc="lower right", fontsize=6.2, ncol=1, frameon=True, framealpha=0.9)
    fig.tight_layout(h_pad=0.8, w_pad=1.0); save(fig, "fig_sim_validation")

def fig_sim_mismatch():
    m = load_sim(); tU = m["tU"]*1e3; names = [str(n) for n in m["names"]]
    nom = {"Vin": 10.0, "L": 22.5e-6, "C": 470e-6, "R": 50.0}
    Gn, Gd = plant_tf(nom, 0.1, float(m["cfg"].Vref))
    t = np.linspace(0, 0.12, 2000)
    pick = [2, 4, 5, 8]; cols = [GREY[2], GREEN, COL_ALGO["PSO"], COL_ALGO["NSGA-II"]]
    fig, axs = plt.subplots(2, 2, figsize=(7.4, 4.3), sharex=True, sharey=True)
    for ax, d, c in zip(axs.ravel(), pick, cols):
        Kp, Ki = float(m["Kp_all"][d]), float(m["Ki_all"][d])
        y = closed_loop_step(Kp, Ki, Gn, Gd, t)
        ax.plot(tU, m["simV"][d][:, 0]/float(m["cfg"].Vref), color=c, lw=1.8, label="Simulink (switching)")
        ax.plot(t*1e3, y, "k--", lw=1.1, label="Averaged model (CCM)")
        ax.axhline(1, color="gray", ls=":", lw=0.8)
        ax.set_xlim(0, 120); ax.set_ylim(0, 1.5); panel(ax, "%s: $K_p$=%.4f, $K_i$=%.1f" % (names[d], Kp, Ki))
    for ax in axs[1]: ax.set_xlabel("Time (ms)")
    for ax in axs[:, 0]: ax.set_ylabel("$V_\\mathrm{out}/V_\\mathrm{ref}$")
    axs[0, 0].legend(loc="lower right", fontsize=6.8, frameon=True)
    fig.tight_layout(h_pad=0.8, w_pad=0.8); save(fig, "fig_sim_mismatch")

def fig_sim_mc():
    m = load_sim(); names = [str(n) for n in m["names"]]; MM = m["MM"]; DM = m["DM"]
    cols = [GREY[0], GREY[1], GREY[2], ORANGE, GREEN] + [COL_ALGO[n] for n in algo_names()]
    ls = ["--"]*5 + ["-"]*4
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.6))
    ax = axs[0]
    for d in range(9):
        v = np.sort(MM[d][~np.isnan(MM[d][:, 2]), 2])*1e3
        ax.plot(v, np.arange(1, len(v)+1)/500.0, color=cols[d], ls=ls[d], lw=1.3, label=names[d])
    ax.axvline(20, color="k", ls=":", lw=0.9); ax.set_xlim(0, 60); ax.set_xlabel("Settling time (ms)"); ax.set_ylabel("Cumulative probability")
    panel(ax, "(a) Settling-time CDF")
    ax = axs[1]
    for d in range(9):
        v = np.sort(MM[d][~np.isnan(MM[d][:, 1]), 1])
        ax.plot(v, np.arange(1, len(v)+1)/500.0, color=cols[d], ls=ls[d], lw=1.3)
    ax.set_xlim(-0.5, 30); ax.set_xlabel("Overshoot (%)"); panel(ax, "(b) Overshoot CDF")
    ax = axs[2]
    worst = np.array([np.nanmax(DM[d][:, 0]) for d in range(9)]); nomv = np.array([DM[d][0, 0] for d in range(9)])
    x = np.arange(9)
    ax.bar(x-0.2, nomv, 0.4, color=cols, alpha=0.55, label="nominal"); ax.bar(x+0.2, worst, 0.4, color=cols, label="worst corner")
    ax.set_xticks(x); ax.set_xticklabels(["wc100", "wc150", "wc300", "Auto", "Slider", "PSO", "GA", "GWO", "NSGA"], rotation=60, fontsize=6.8)
    ax.set_ylabel("Peak deviation (% of $V_\\mathrm{ref}$)"); panel(ax, "(c) $-20\\,\\%$ line step")
    h = [Line2D([0], [0], color="gray", lw=6, alpha=0.5), Line2D([0], [0], color="gray", lw=6)]
    ax.legend(h, ["nominal", "worst corner"], fontsize=6.8, loc="upper right", frameon=False)
    axs[0].legend(fontsize=5.6, loc="lower right", frameon=True, framealpha=0.9)
    fig.tight_layout(w_pad=1.0); save(fig, "fig_sim_mc")

if __name__ == "__main__":
    fig_sim_conv_stats(); fig_sim_validation(); fig_sim_mismatch(); fig_sim_mc()
