"""DCM-aware reduced-order averaged model of the boost converter (Erickson & Maksimovic, Sec. 11; Sun et al. 2001).
Operating point from the target output voltage: M = Vo/Vin, K = 2 L fs / R, D = sqrt(K M (M-1)).
Control-to-output (inductor dynamics neglected, valid below fs/2):  Gvd(s) = Gd0 / (1 + s/wp)
    Gd0 = 2 V/D * (M-1)/(2M-1),   wp = (2M-1)/((M-1) R C)
CCM check: if K > (1-D_ccm)^2 the converter is in CCM and the CCM model of Study B is returned instead."""
import numpy as np
from scipy import signal

def op_point(Vin, Vo, L, fs, R):
    M = Vo/Vin; K = 2*L*fs/R
    Dccm = 1 - 1/M
    if K > (1-Dccm)**2: return dict(mode="CCM", M=M, K=K, D=Dccm)
    return dict(mode="DCM", M=M, K=K, D=np.sqrt(K*M*(M-1)))

def plant_dcm(Vin, Vo, L, C, R, fs):
    op = op_point(Vin, Vo, L, fs, R); M, D = op["M"], op["D"]
    Gd0 = 2*Vo/D*(M-1)/(2*M-1); wp = (2*M-1)/((M-1)*R*C)
    return op, Gd0, wp

def plant_ccm(Vin, Vo, L, C, R, RL=0.1):
    Dp = Vin/Vo
    a = Vin/Dp**2; b = L/(R*Dp**2); c = L*C/Dp**2; bL = (L/R+RL*C)/Dp**2; dc = 1+RL/(R*Dp**2)
    return np.array([-a*b, a]), np.array([c, bL, dc])

def step_metrics(t, y):
    y = np.asarray(y); os_ = max(0, (y.max()-1))*100
    o = np.where(np.abs(1-y) > 0.02)[0]; ts = 0 if len(o) == 0 else (t[min(o[-1]+1, len(t)-1)])
    a = np.argmax(y >= 0.1); b = np.argmax(y >= 0.9); tr = t[b]-t[a] if y.max() >= 0.9 else np.nan
    return os_, ts, tr

def closed_loop(Kp, Ki, num, den, t, delay=0.0, k=1000.0):
    """unit-step response of PI + plant (+ optional Pade(2) delay); polynomials rescaled s=k p for conditioning."""
    num = np.atleast_1d(num); den = np.atleast_1d(den)
    if delay > 0:
        d = delay; pn = [d**2/12, -d/2, 1]; pd = [d**2/12, d/2, 1]; num = np.convolve(num, pn); den = np.convolve(den, pd)
    numL = np.convolve([Kp, Ki], num); denL = np.convolve([1, 0], den)
    denT = denL.copy(); denT[len(denL)-len(numL):] += numL
    sc = lambda p: np.array([c*k**(len(p)-1-i) for i, c in enumerate(p)])
    _, y = signal.step(signal.TransferFunction(sc(numL), sc(denT)), T=np.asarray(t)*k)
    return y

if __name__ == "__main__":
    L, C, R, fs = 22.5e-6, 470e-6, 50.0, 62.5e3
    for Vin, Vo in [(10, 18.18), (7.2, 8), (7.2, 12), (7.2, 15)]:
        op, G0, wp = plant_dcm(Vin, Vo, L, C, R, fs)
        print(f"Vin {Vin} Vo {Vo}: {op['mode']}  D={op['D']:.3f}  Gd0={G0:.1f} V  pole={wp:.0f} rad/s ({wp/2/np.pi:.0f} Hz)")
    t = np.linspace(0, 0.12, 4000)
    Vin, Vo = 10, 18.18; op, G0, wp = plant_dcm(Vin, Vo, L, C, R, fs); nC, dC = plant_ccm(Vin, Vo, L, C, R)
    for nm, kp, ki in [("PSO/GWO sim", 0.01614, 44.96), ("slider", 0.00243, 15.314), ("pidtune300", 0.0, 9.1165), ("pidtune100", 0.0, 3.0443)]:
        yd = closed_loop(kp, ki, [G0], [1/wp, 1], t); yc = closed_loop(kp, ki, nC, dC, t)
        print(nm, "DCM-reduced OS %.1f Ts %.1f ms | CCM OS %.1f Ts %.1f ms" % (step_metrics(t, yd)[0], step_metrics(t, yd)[1]*1e3, step_metrics(t, yc)[0], step_metrics(t, yc)[1]*1e3))
