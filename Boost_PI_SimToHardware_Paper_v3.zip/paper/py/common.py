"""Common style + data loading for the paper figures (Python 3, numpy, scipy, matplotlib)."""
import os, numpy as np, scipy.io as sio, pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
FIG  = os.path.join(ROOT, "figures")
DATA = os.environ.get("PAPER_DATA", "/home/claude/w")      # folder with the unzipped result files
os.makedirs(FIG, exist_ok=True)

mpl.rcParams.update({
    "font.family": "serif",
    "font.serif": ["TeX Gyre Termes", "Liberation Serif", "STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9, "legend.fontsize": 7.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.5,
    "axes.linewidth": 0.8, "lines.linewidth": 1.4,
    "savefig.dpi": 300, "savefig.bbox": "tight", "pdf.fonttype": 42,
})

# colours: optimisers (as in the MATLAB figures), references (grey scale), scaled simulation designs (greens)
COL_ALGO = {"PSO": (0.00, 0.45, 0.74), "GA": (0.93, 0.69, 0.13), "GWO": (0.49, 0.18, 0.56), "NSGA-II": (0.64, 0.08, 0.18)}
GREY = [(0.60,)*3, (0.40,)*3, (0.15,)*3]
ORANGE = (0.85, 0.33, 0.10); GREEN = (0.47, 0.67, 0.19)
SCALE = 255.0 * 25.0 / 1023.0          # simulation gain -> Arduino gain (duty counts per ADC count)

def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".pdf"))
    fig.savefig(os.path.join(FIG, name + ".png"))
    plt.close(fig)
    print("saved", name)

def panel(ax, s):
    ax.set_title(s, fontsize=9, fontweight="normal")

def load_sim():
    return sio.loadmat(os.path.join(DATA, "Final_Results/PI_Opt_Results.mat"), squeeze_me=True, struct_as_record=False)

def load_hw():
    return sio.loadmat(os.path.join(DATA, "HW_Final_Results/HW_Opt_Results.mat"), squeeze_me=True, struct_as_record=False)

def load_hwval():
    return sio.loadmat(os.path.join(DATA, "HW_Final_Results/HW_Validation.mat"), squeeze_me=True, struct_as_record=False)

def hw_table(name):
    return pd.read_csv(os.path.join(DATA, "HW_Final_Results/HW_Tables", name))

def sim_table(name):
    return pd.read_csv(os.path.join(DATA, "Final_Results/Paper_Tables", name))

# ------------------------------------------------------------------ averaged (CCM) model of the prototype
def plant_tf(s, nom_RL=0.1, Vref=10/(1-0.45)):
    """duty -> Vout small-signal model used by the optimiser (same equations as buildCtx in the MATLAB script)."""
    Ds = 1 - s["Vin"]/Vref
    a  = s["Vin"]/(1-Ds)**2;  b = s["L"]/(s["R"]*(1-Ds)**2)
    c  = s["L"]*s["C"]/(1-Ds)**2
    bL = (s["L"]/s["R"] + nom_RL*s["C"])/(1-Ds)**2
    dc = 1 + nom_RL/(s["R"]*(1-Ds)**2)
    return np.array([-a*b, a]), np.array([c, bL, dc])

def closed_loop_step(Kp, Ki, Gn, Gd, t, k=1000.0):
    """unit-step response of the PI + plant loop; polynomials are rescaled (s = k p) to keep the numerics well conditioned."""
    from scipy import signal
    def sc(p):      # highest power first
        n = len(p); return np.array([c*k**(n-1-i) for i, c in enumerate(p)])
    numL = np.convolve([Kp, Ki], Gn);  denL = np.convolve([1, 0], Gd)
    denT = denL.copy(); denT[len(denL)-len(numL):] += numL
    _, y = signal.step(signal.TransferFunction(sc(numL), sc(denT)), T=np.asarray(t)*k)
    return y
