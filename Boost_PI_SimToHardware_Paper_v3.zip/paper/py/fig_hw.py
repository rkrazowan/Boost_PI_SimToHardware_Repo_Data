from common import *
from matplotlib.lines import Line2D
ALG = ["PSO", "GA", "GWO", "NSGA-II"]

def fig_hw_conv_stats():
    h = load_hw(); R = h["Res"]
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.55), gridspec_kw={"width_ratios": [1.15, 0.9, 1.05]})
    ax = axs[0]
    for a, nm in enumerate(ALG):
        hh = np.atleast_2d(R[a].hist); mu, sd = hh.mean(0), hh.std(0); x = np.arange(hh.shape[1])
        ax.fill_between(x, mu-sd, mu+sd, color=COL_ALGO[nm], alpha=0.15, lw=0); ax.plot(x, mu, color=COL_ALGO[nm], label=nm)
    ax.set_yscale("log"); ax.set_xlabel("Iteration"); ax.set_ylabel("Measured cost $J$"); ax.legend(frameon=False, loc="upper right")
    panel(ax, "(a) Convergence (mean $\\pm$ 1 s.d., 3 runs)")
    ax = axs[1]
    for a, nm in enumerate(ALG):
        v = np.atleast_1d(R[a].Jre); ax.plot([a+1]*len(v), v, "o", color=COL_ALGO[nm], ms=5)
        ax.hlines(v.mean(), a+0.7, a+1.3, color="k", lw=1.2)
    ax.set_xticks(range(1, 5)); ax.set_xticklabels(ALG, fontsize=7.5); ax.set_ylabel("Re-evaluated cost $J$"); ax.set_xlim(0.5, 4.5)
    panel(ax, "(b) Per-run result (bar: mean)")
    ax = axs[2]
    for a, nm in enumerate(ALG):
        x = np.atleast_2d(R[a].x); ax.plot(x[:, 0], x[:, 1], "o", color=COL_ALGO[nm], ms=4.5, label=nm)
    ax.plot([0.1, 0.05], [20, 10], "s", mfc="#ffe44d", mec="k", ms=5.5)
    ax.annotate("Baseline", (0.1, 20), xytext=(-4, 5), textcoords="offset points", fontsize=6.5, ha="right")
    ax.annotate("Ref", (0.05, 10), xytext=(4, -9), textcoords="offset points", fontsize=6.5)
    ax.set_yscale("log"); ax.set_xlim(-0.02, 0.5); ax.set_ylim(2, 200); ax.set_xlabel("$K_P$ (Arduino units)"); ax.set_ylabel("$K_I$")
    panel(ax, "(c) Best gains of each run")
    fig.tight_layout(w_pad=1.0); save(fig, "fig_hw_conv_stats")

def fig_hw_landscape():
    h = load_hw(); L = h["hwlog"]; tr = sim_scaled()
    Kp, Ki, J = L[:, 2], L[:, 3], L[:, 4]
    fig, ax = plt.subplots(figsize=(4.6, 3.5))
    ok = J < 100
    sc = ax.scatter(Kp[ok], Ki[ok], c=np.log10(J[ok]), s=7, cmap="viridis_r", alpha=0.8, vmin=-0.4, vmax=1.0)
    if (~ok).any(): ax.plot(Kp[~ok], Ki[~ok], "kx", ms=3, label="failed / aborted test")
    cb = fig.colorbar(sc, ax=ax, pad=0.02); cb.set_label("$\\log_{10}J$ (single measurement)")
    ax.plot(tr["Kp_hw"], tr["Ki_hw"], "*", mfc="#ff3b30", mec="k", ms=10, label="scaled simulation designs")
    for n, k, i in zip(tr["name"], tr["Kp_hw"], tr["Ki_hw"]):
        ax.annotate(n.replace("Sim ", "").replace("Sim-", ""), (k, i), xytext=(4, 3), textcoords="offset points", fontsize=6.3)
    ax.set_yscale("log"); ax.set_xlim(-0.01, 0.5); ax.set_ylim(2, 400); ax.set_xlabel("$K_P$ (Arduino units)"); ax.set_ylabel("$K_I$")
    ax.legend(fontsize=6.8, loc="upper right", frameon=True)
    save(fig, "fig_hw_landscape")

def sim_scaled():
    t = hw_table("Table_Sim_vs_Hardware.csv")
    return {"name": list(t["Design"]), "Kp_hw": t["Kp_hw"].values, "Ki_hw": t["Ki_hw"].values}

def fig_hw_steps():
    v = load_hwval(); names = [str(n) for n in v["names"]]; tG = v["tG"]*1e3; VG = v["VG"]
    lv = [8, 12, 15, 12, 8]; ttl = ["8 \u2192 12 V", "12 \u2192 15 V", "15 \u2192 12 V", "12 \u2192 8 V"]
    cols = [GREY[1], GREY[0]] + [COL_ALGO[n] for n in ALG]; ls = ["--", "-."] + ["-"]*4
    fig, axs = plt.subplots(2, 2, figsize=(7.4, 5.0))
    for k, ax in enumerate(axs.ravel()):
        for d in range(6):
            y = np.nanmean(VG[d][:, k, :], axis=1)
            ax.plot(tG, y, color=cols[d], ls=ls[d], lw=1.2, label=names[d])
        ax.axhline(lv[k+1], color="k", ls=":", lw=1); ax.set_xlim(-250, 800); ax.set_xlabel("Time after step (ms)"); ax.set_ylabel("$V_\\mathrm{out}$ (V)")
        panel(ax, "(%s) %s" % ("abcd"[k], ttl[k]))
    axs[0, 0].legend(fontsize=6.5, loc="lower right", frameon=True)
    fig.tight_layout(h_pad=0.8, w_pad=0.8); save(fig, "fig_hw_steps")

def fig_hw_metrics():
    t = hw_table("Table_Hardware_Validation.csv"); e = hw_table("Table_Hardware_Ensemble.csv")
    nm = ["Baseline\n(0.1, 20)", "Ref\n(0.05, 10)", "PSO", "GA", "GWO", "NSGA-II\nknee"]
    cols = [GREY[1], GREY[0]] + [COL_ALGO[n] for n in ALG]
    fig, axs = plt.subplots(1, 4, figsize=(7.4, 2.5)); x = np.arange(6)
    spec = [("J_mean", "J_sd", "(a) Validation cost $J$"), ("WorstOS_pct", "OS_sd", "(b) Worst overshoot (%)"),
            ("WorstTr_ms", None, "(c) Worst rise time (ms)"), ("WorstSSerr_pct", None, "(d) Worst steady error (%)")]
    for ax, (c, s, ttl) in zip(axs, spec):
        ax.bar(x, t[c].values, yerr=None if s is None else t[s].values, color=cols, capsize=2, edgecolor="k", lw=0.5)
        ax.set_xticks(x); ax.set_xticklabels(nm, rotation=70, fontsize=6.2); panel(ax, ttl)
        if c == "WorstTr_ms": ax.set_yscale("log")
    fig.tight_layout(w_pad=0.8); save(fig, "fig_hw_metrics")

def fig_hw_duty_zoom():
    v = load_hwval(); names = [str(n) for n in v["names"]]; tG = v["tG"]*1e3; VG = v["VG"]; DG = v["DG"]
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.5))
    for d in range(2, 6):
        axs[0].plot(tG, np.nanmean(VG[d][:, 2, :], axis=1), color=COL_ALGO[ALG[d-2]], label=names[d])
        axs[1].plot(tG, np.nanmean(DG[d][:, 0, :], axis=1), color=COL_ALGO[ALG[d-2]])
    axs[0].axhline(12, color="k", ls=":", lw=1); axs[0].set_xlim(-50, 300); axs[0].set_ylim(11, 15.4)
    axs[0].set_xlabel("Time after step (ms)"); axs[0].set_ylabel("$V_\\mathrm{out}$ (V)"); panel(axs[0], "(a) 15 \u2192 12 V step (zoom)")
    axs[1].set_xlim(-50, 300); axs[1].set_xlabel("Time after step (ms)"); axs[1].set_ylabel("Duty (%)"); panel(axs[1], "(b) Duty ratio, 8 \u2192 12 V step")
    axs[0].legend(fontsize=6.5, frameon=False)
    fig.tight_layout(w_pad=1.0); save(fig, "fig_hw_duty_zoom")

if __name__ == "__main__":
    fig_hw_conv_stats(); fig_hw_landscape(); fig_hw_steps(); fig_hw_metrics()
