# Overleaf package: simulation-to-hardware PI tuning of a boost converter (Arduino + MATLAB)

## How to use
1. Overleaf > New Project > Upload Project > select this zip.
2. Compiler = **pdfLaTeX**, main document = `main.tex`, compile twice (BibTeX runs automatically; style `IEEEtran`).
3. `main_preview.pdf` is a pre-built copy made locally with a plain bibliography style (`ieeetr`) and without `microtype`; your Overleaf build with `IEEEtran` will differ slightly in reference formatting and page count.

## Structure of the paper
| File | Section |
|---|---|
| `sections/abstract_ieee.tex` | Abstract + keywords (rewritten) |
| `01_introduction.tex` | Extended introduction and literature (new strand: low-cost platforms, reality gap, HIL tuning) |
| `02_models.tex` | Converters and models: Study A (500 W, old text), Study B (new: parameters, averaged model, conduction-mode check) |
| `03_method.tex` | Overall framework (Fig. framework) + Study A methodology (old text) |
| `04_setupB.tex` | **New:** Simulation setup of the laboratory-scale converter |
| `05_hwmethod.tex` | **New:** Hardware platform, firmware, serial protocol, **gain scaling**, tests, HIL optimization |
| `06_resA.tex` | Results of Study A (old results, unchanged) |
| `07_resB_sim.tex` | **New:** Study B simulation results |
| `08_resHW.tex` | **New:** Hardware optimization and validation |
| `09_transfer.tex` | **New:** Bench re-test of the scaled simulation gains (5 repeats, derated versions, controls), comparison with hardware-tuned gains, sampled-controller simulation (Part A/B), possible causes |
| `10_discussion.tex`, `11_conclusions.tex` | Discussion (old Study A discussion kept) and conclusions (incl. no dSPACE/STM32 statement) |
| `12_backmatter.tex` | Conflicts, AI-use declaration (author/funding blocks still commented out as before) |

## Figures and tables
* `figures/` : Study A figures are your originals. All other figures are generated with Python from your result files by `py/` (PDF for the paper, PNG copies for Word).
* `tables/` : generated from your CSV files by `py/make_tables.py` (no number typed by hand).
* To regenerate: put `Final_Results/` and `HW_Final_Results/` (the unzipped folders) in one directory, then
  `PAPER_DATA=/path/to/that/directory python3 py/fig_diagrams.py; python3 py/fig_sim.py; python3 py/fig_hw.py; python3 py/fig_transfer.py; python3 py/make_tables.py`
  (needs numpy, scipy, pandas, matplotlib).
* `figures/_not_used/`: the old methodology figure (replaced by `fig_framework`; it contained font glitches such as "eßort") and the two earlier wrong-figure files.
* `figures/fig_simulink_modelB.png` is your screenshot; it still shows the constant "6" at the reference block, whereas the simulation uses 18.18 V. Re-capture it with the final reference value.
* `matlab_arduino/`: your optimisation scripts, the Arduino sketch, the Simulink model, and the two check scripts `Run_Sim_Delay_and_HWlike.m` and `Run_HW_Retest.m`.
* `results_extra/`: the raw outputs of the two check scripts (`HW_Retest.*`, `Sim_Check_Results*.csv`, log, plot). `py/fig_extra.py` regenerates the new figures/tables from them (put them in `<PAPER_DATA>/extra/`).

## Things left for you (not written because they were not in your files)
* Authors, affiliations, funding, data DOI (blocks are commented out as before).
* Make/part numbers of the MOSFET and driver module, inductor, capacitor, supply and measuring instruments (the text says only "MOSFET with driver module", SR506, etc.).
* Protocol of the EARLIER single measurement in `Table_Sim_vs_Hardware.csv` (cited in one sentence of `09_transfer.tex`, `TODO` comment there): add its protocol or delete the sentence. Its settling times (805--980 ms) exceed the 0.8 s capture window of the optimization script.
* Measure the firmware loop delay (`micros()` before/after `analogRead`) and add one sentence in Section 9.5.
* References added for the new literature (see the header of `references.bib`): please verify the entries marked there.

## Added in v3 (review round)
* New: `tables/tab_costsens.tex` + `py/cost_sensitivity.py` (cost-weight sensitivity from stored data), `py/dcm_model.py` (reduced-order DCM model, NOT yet used in the paper: waiting for the validation data of `Run_Model_Validation.m`).
* `matlab_arduino/Run_Model_Validation.m`: small-step switching-model traces for model validation (CCM vs DCM vs switching).
* `matlab_arduino/boost_controller_TIMING_TEST.ino`: measures ADC time, control-cycle time and period jitter; put the numbers into Section 5.7 (`TODO` there).
* `references.bib`: entries `zakki` and `sobraep2021` have no year/authors yet (found by web search): complete them.
* Section 12 (Data and Code Availability): fill in the repository DOI.
